function cambiaTextoModal(textoh2,textoh3){
    document.getElementById("precioModal").innerHTML="Precio: "+textoh2+"€";
    document.getElementById("tipoModal").innerHTML="Tipo: "+textoh3;

}